
#include "@@FULLPROJECTNAME@@.h"

@implementation @@FULLPROJECTNAME@@

- (id)specifiers {
	if (_specifiers == nil) {
		_specifiers = [[self loadSpecifiersFromPlistName:@"Root" target:self] retain];
	}
	return _specifiers;
}

- (instancetype)init {
    self = [super init];

    if (self) {
        HBAppearanceSettings *appearanceSettings = [[HBAppearanceSettings alloc] init];
        appearanceSettings.tintColor = [UIColor colorWithRed:1.00 green:0.7 blue:0.72 alpha:1.0];
        appearanceSettings.tableViewCellSeparatorColor = [UIColor colorWithRed:1.00 green:0.7 blue:0.72 alpha:1.0];
        self.hb_appearanceSettings = appearanceSettings;
        self.respringButton = [[UIBarButtonItem alloc] initWithTitle:@"Apply" 
                                    style:UIBarButtonItemStylePlain
                                    target:self 
                                    action:@selector(respring:)];
        self.respringButton.tintColor = [UIColor colorWithRed:1.00 green:0.7 blue:0.72 alpha:1.0];
        self.navigationItem.rightBarButtonItem = self.respringButton;
    }

    return self;
}

-(void) contactMethod
{
UIAlertView *alert1 = [[UIAlertView alloc]initWithTitle:@"Twitter ID" message:@"sugi.uta @uta_sugi" delegate:self cancelButtonTitle:@"Open Twitter" otherButtonTitles:nil];
[alert1 show];
}

-(void)alertView:(UIAlertView *)alertView  clickedButtonAtIndex:(NSInteger)buttonIndex {
NSString *button = [alertView buttonTitleAtIndex:buttonIndex];

if([button isEqualToString:@"Open Twitter"])
{//Open Twitterボタンを押した場合の対応
[[UIApplication sharedApplication]openURL:[NSURL URLWithString:@"https://mobile.twitter.com/uta_sugi"]];
}
}

- (void)respring:(id)sender {

UIViewController *view = [UIApplication sharedApplication].keyWindow.rootViewController;
        while (view.presentedViewController != nil && !view.presentedViewController.isBeingDismissed) {
                view = view.presentedViewController;
        }
    UIAlertController *alertController = 
    [UIAlertController alertControllerWithTitle:@"Confirmation" 
                                        message:@"Do you want to respring?" 
                                 preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:@"Yes" 
                                                        style:UIAlertActionStyleDefault 
                                                      handler:^(UIAlertAction *action) {
            NSTask *t = [[NSTask alloc] init];
    [t setLaunchPath:@"/usr/bin/killall"];
    [t setArguments:[NSArray arrayWithObjects:@"backboardd", nil]];
    [t launch];                                                    
    }]];
    [alertController addAction:[UIAlertAction actionWithTitle:@"No" 
                                                        style:UIAlertActionStyleDefault 
                                                      handler:^(UIAlertAction *action) {
        //??                                                     
    }]];
    [view presentViewController:alertController animated:YES completion:nil];

}


-(void)github {
		 	 			[[UIApplication sharedApplication]
		 	 			openURL:[NSURL URLWithString:@"https://github.com/sugiuta"]
		 	 			options:@{}
		 	 			completionHandler:nil];
		 	 				}

-(void)paypal {
		 	 			[[UIApplication sharedApplication]
		 	 			openURL:[NSURL URLWithString:@"https://www.paypal.me/sugiuta1203"]
		 	 			options:@{}
		 	 			completionHandler:nil];
		 	 				}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    CGRect frame = self.table.bounds;
    frame.origin.y = -frame.size.height;

    [self.navigationController.navigationController.navigationBar setShadowImage: [UIImage new]];
    self.navigationController.navigationController.navigationBar.translucent = YES;
}


-(void)showExplanation:(UIAlertController *)expController {

expController = [UIAlertController alertControllerWithTitle:@"@@FULLPROJECTNAME@@" message:@"Alert message" preferredStyle:UIAlertControllerStyleAlert];
                          UIAlertAction *alertAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];

UIAlertAction *installAction = [UIAlertAction actionWithTitle:@"Install Activator" style:UIAlertActionStyleDefault
   handler:^(UIAlertAction * action) {
[[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"cydia://url/https://cydia.saurik.com/package/libactivator/"] options:@{} completionHandler:nil];
}];
    

   [expController addAction: installAction];
     [expController addAction:alertAction];

                          [self presentViewController:expController animated:YES completion:nil];

}


@end
